function TestApp() {
  return (
    <div style={{ padding: '20px', color: 'white', backgroundColor: '#111' }}>
      <h1>SocratesTrader</h1>
      <p>Application is loading...</p>
    </div>
  );
}

export default TestApp;